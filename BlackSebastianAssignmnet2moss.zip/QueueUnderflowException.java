
/**
 * An exception that ensures a dequeue method is not called on an empty queue
 * @author Sebastian Black
 */
public class QueueUnderflowException extends RuntimeException 
{
    /**
     * if invalid then the following message will appear
     */
    public QueueUnderflowException() 
    {
        super("There is a Notation dequeue method called on an empty queue");
    }
}