
public class Notation {
	/**
	 * @author Sebastian Black
	 * 
	 */
	public static int operations(String order) 
	{ 
		switch (order) 
		{
		case ("+"):
		case ("-"):
			return 1;
		case ("*"):
		case ("/"):
			return 2;
		}
		return -1;
	}

	/**
	 * Convert an infix to postfix 
	 */
	public static String convertInfixToPostfix(String infix)
	{
		MyStack<String> mystack = new MyStack<String>(100);  
		MyQueue<String> myqueue = new MyQueue<String>(100); 
		for (int i = 0; i < infix.length(); i++) 
		{ 
			char character = infix.charAt(i);
			if (Character.isDigit(character)) 
			{
				myqueue.enqueue(Character.toString(character));
			} 
			else if (character == '(') 
			{ 
				mystack.push(Character.toString(character));
			}
			 else if (character == '+' || character == '-' || character == '/' || character == '*')
			{
				while (!mystack.isEmpty() && operations(mystack.top()) >= operations(Character.toString(character))) 
				{
					myqueue.enqueue(mystack.pop()); 
				}
					mystack.push(Character.toString(character)); 
			}
			 else if (character == ')') 
			{
				while (!mystack.isEmpty() && !mystack.top().equals("(")) 
				{
					myqueue.enqueue(mystack.pop());
				} 
				if (!mystack.isEmpty()) 
				{
					mystack.pop(); 
				} 
				else 
				{
					throw new InvalidNotationFormatException();
				}	
			}
		} 
		return myqueue.toString();
	}
	/**
	 * Convert  Postfix to Infix 
	 */
	public static String convertPostfixToInfix(String postfix) 
	{
		String variable1,variable2 = null;
		MyStack<String> mystack = new MyStack<String>(100); 
		for (int i = 0; i < postfix.length(); i++)
			{
			if (Character.isDigit(postfix.charAt(i)))
			{
					mystack.push(Character.toString(postfix.charAt(i)));
			}
			else if ((postfix.charAt(i)) == '+' || postfix.charAt(i) == '-' || postfix.charAt(i) == '*'|| postfix.charAt(i) == '/') 
			{
				if (mystack.size() < 2) 
				{ 
					throw new InvalidNotationFormatException();
				} 
				else 
				{
						variable1 = mystack.pop();
						variable2 = mystack.pop();
				}
					String Encapsulate = "(" + variable2 + postfix.charAt(i) + variable1 + ")"; 
						mystack.push(Encapsulate);
				}
			}
		if (mystack.size() > 1)
		{
			throw new InvalidNotationFormatException();
		} else 
		{
			return mystack.pop();
		}
	}
	/**
	 * turn postfix string to a double
	 */
	public static Double evaluatePostfixExpression(String postfixexpression) 
	{
		String variable1,variable2 = null;
		MyStack<String> mystack = new MyStack<String>(100); 
		for (int i = 0; i < postfixexpression.length(); i++) 
		{ 
			if (Character.isDigit(postfixexpression.charAt(i))) 
			{ 
				mystack.push(Character.toString(postfixexpression.charAt(i)));
			}
			else if ((postfixexpression.charAt(i)) == '+' || postfixexpression.charAt(i) == '-' || postfixexpression.charAt(i) == '*'|| postfixexpression.charAt(i) == '/') 
			{
				if (mystack.size() < 2) 
				{ 
					throw new InvalidNotationFormatException();
				} 
				else 
				{
					variable1 = mystack.pop();
					variable2 = mystack.pop();
					
					double calculation = 0.0;
					if (postfixexpression.charAt(i) == '+') 
					{
						Double Variable1 = Double.parseDouble(variable1);
						Double Variable2 = Double.parseDouble(variable2);
						calculation =+ Variable2 + Variable1;
					}

					else if (postfixexpression.charAt(i) == '-')
					{
						Double Variable1 = Double.parseDouble(variable1);
						Double Variable2 = Double.parseDouble(variable2);
						calculation =+ Variable2 - Variable1;
					} 
					else if (postfixexpression.charAt(i) == '*') 
					{
						Double Variable1 = Double.parseDouble(variable1);
						Double Variable2 = Double.parseDouble(variable2);
						calculation =+ Variable2 * Variable1;
					} 
					else if (postfixexpression.charAt(i) == '/') 
					{
						Double Variable1 = Double.parseDouble(variable1);
						Double Variable2 = Double.parseDouble(variable2);
						calculation =+ Variable2 / Variable1;
					}
						mystack.push(String.valueOf(calculation));
					{
					} 
				}
			}

		}

		if (mystack.size() > 1)
		{
			throw new InvalidNotationFormatException();
		}
		 else 
		 {
				return Double.parseDouble(mystack.pop());
		 }
	}
}