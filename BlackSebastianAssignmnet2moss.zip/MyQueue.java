import java.util.ArrayList;

/**
 * Interface for a Queue data structure
 * @author Sebastian Black
 * @param <T> data type
 */
public class MyQueue <T> implements QueueInterface<T>
{
	private int size= 100;
	private ArrayList<T> queue;
	public MyQueue(int Size) 
	{
        queue = new ArrayList<>(Size);
        this.size = Size;
	}
	/**
	 * @param checks if queue is empty
	 */
    @Override
    public boolean isEmpty() 
    {
        return queue.isEmpty();
    }
    /**
	 * @param checks if queue is full
	 */
    @Override
    public boolean isFull() 
    {
        return queue.size() == size;
    }
    /**
	 * @param returns the number of elements in the queue but checks if it is empty first
	 */
    @Override
    public T dequeue() throws QueueUnderflowException 
    {
        if (isEmpty()) 
        {
        	throw new QueueUnderflowException();
        }
        else 
        {
            T element = queue.get(0);
            queue.remove(0);
            return element;
        } 
            
    }
    /**
	 * @param returns the size of queue
	 */
    @Override
    public int size() 
    {
        return queue.size();
    }
    /**
	 * @param returns the number of elements in the queue but checks if it is full first
	 */
    @Override
    public boolean enqueue(T element) throws QueueOverflowException {
        if (isFull()) 
        {
        	throw new QueueOverflowException();
        } 
        else 
        {
           return queue.add(element);
        }
    }

    @Override
    public String toString() 
    {
        String repofelements = "";
        for (int element = 0; element < queue.size(); element++) 
        {
        	repofelements += queue.get(element);
        }
        return repofelements;
    }
    
    @Override
    public String toString(String delimiter) 
    {
        String repofelements = "";
        for (int element = 0; element < queue.size(); element++) 
        {
        	if(element == queue.size()-1)
        	{
        		repofelements += queue.get(element);
        	}
        	else
        	{
        	repofelements += queue.get(element) + delimiter;
        	}
        }
        return repofelements;
    }

    @Override
    public void fill(ArrayList<T> list) 
    {
    	if (isFull()) 
      	 {
       	throw new QueueOverflowException();
        } 
       	else
       	{
       	ArrayList<T> Copy =new ArrayList<T>(list);
       	queue.addAll(Copy);
       	size = queue.size();
       	}
    	
        
    }
    
}