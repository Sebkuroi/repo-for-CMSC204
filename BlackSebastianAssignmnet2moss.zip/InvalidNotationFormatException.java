
/**
 * An exception that ensures the Notation format is correct
 * @author Sebastian Black
 */
public class InvalidNotationFormatException extends RuntimeException 
{
    /**
     * if invalid then the following message will appear
     */
    public InvalidNotationFormatException() 
    {
        super("The Notation format is incorrect");
    }
}