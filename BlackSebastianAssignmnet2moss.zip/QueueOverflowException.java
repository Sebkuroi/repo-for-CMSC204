
/**
 * An exception that ensures a enqueue method is not called on a full queue
 * @author Sebastian Black
 */
public class QueueOverflowException extends RuntimeException 
{
    /**
     * if invalid then the following message will appear
     */
    public QueueOverflowException() 
    {
        super("There is a enqueue method called on a full queue");
    }
}