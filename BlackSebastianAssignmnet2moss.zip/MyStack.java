import java.util.ArrayList;

/**
 * utility for a generic Stack data structure
 * @author Sebastian Black
 * @param <T> data type
 */
public class MyStack<T> implements StackInterface<T> 
{
	private int size= 100;
	private ArrayList<T> stack;
	public MyStack(int Size) 
	{
		stack = new ArrayList<>(Size);
        this.size = Size;
	}
	/**
	 * @param checks if queue is empty
	 */
    @Override
    public boolean isEmpty() {
        return stack.isEmpty();
    }
    /**
   	 * @param checks if queue is full
   	 */
    @Override
    public boolean isFull() {
        return stack.size() == size;
    }
    /**
	 * @param Deletes and returns the element at the top of the Stack
	 */
    @Override
    public T pop() throws StackUnderflowException 
    {
    	if (isEmpty()) 
    	{
    		throw new StackUnderflowException();
    	}
    	else 
        { 
        	 T element = stack.get(size() - 1);
             stack.remove(size() - 1);
             return element;
        }
    }
    /**
   	 * @param Returns the element at the top of the Stack, does not pop it off the Stack
   	 */
    @Override
    public T top() throws StackUnderflowException
    {
    	if (isEmpty()) 
    	{
    		throw new StackUnderflowException();
    	}
    	else 
        { 
        	 T element = stack.get(size() - 1);
             return element;
        }
    }
    /**
	 * @param Number of elements in the Stack
	 */
    @Override
    public int size() 
    {
        return stack.size();
    }
    /**
	 * Returns the elements of the Stack in a string from bottom to top, the beginning 
	 */
    @Override
    public boolean push(T e) throws StackOverflowException 
    {
        if (isFull()) 
        {
        	throw new StackOverflowException();
        } 
        else 
        {
        	stack.add(e);
        	return true;
        }
    }

    @Override
    public String toString() 
    {
        String repofelements = "";
        for (int element = 0; element < stack.size(); element++) 
        {
        	repofelements += stack.get(element);
        }
        return repofelements;
    }
    
    @Override
    public String toString(String delimiter) 
    {
    	String repofelements = "";
    	for (int element = 0; element < stack.size(); element++) 
    	{
    		if(element == stack.size()-1)
        	{
        		repofelements += stack.get(element);
        	}
        	else
        	{
        	repofelements += stack.get(element) + delimiter;
        	}
    	}
    	return repofelements;
    }

    @Override
    public void fill(ArrayList<T> list) throws StackOverflowException 
  {
    	if (isFull()) 
   	 {
    	throw new QueueOverflowException();
     } 
    	else
    	{
    	ArrayList<T> Copy =new ArrayList<T>(list);
    	stack.addAll(Copy);
    	size = stack.size();
    	}
    	 
    }
 }
    	
        