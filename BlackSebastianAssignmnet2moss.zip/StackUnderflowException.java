
/**
 * An exception that ensures top or pop method is not called on an empty stack
 * @author Sebastian Black
 */
public class StackUnderflowException extends RuntimeException 
{
    /**
     * if invalid then the following message will appear
     */
    public StackUnderflowException() 
    {
        super("There is a top or pop method is called on an empty stack");
    }
}