
/**
 * An exception that ensures the push method is not called on a full stack
 * @author Sebastian Black
 */
public class StackOverflowException extends RuntimeException 
{
    /**
     * if invalid then the following message will appear
     */
    public StackOverflowException() 
    {
        super("There is a a push method is called on a full stack");
    }
}