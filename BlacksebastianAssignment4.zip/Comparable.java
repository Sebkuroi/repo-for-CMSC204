	
	public interface Comparable 
	{
		int compareTo(CourseDBElement element);
	}